from django.shortcuts import render, redirect
from app.models import Resume
from easy_pdf.views import PDFTemplateResponseMixin
from django.views.generic import DetailView
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
# Create your views here.

def home(request):
    resume = Resume.objects.all()
    context = {
        'resume' : resume
    }
    return render(request, "home.html", context)

def signup(request):
    form = UserCreationForm()
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid:
            form.save()
    context ={
        'form' : form
    }
    return render(request,"signup.html",context)

@login_required
def logout(request):
    return render(request,"logout.html")

@login_required
def fetchData(request, id):
    resumedetail = Resume.objects.get(id=id)
    context={
        'resumedetail' : resumedetail
    }
    return render(request, "resume.html", context)

@login_required
def deleteData(request, id):
    delete_resume = Resume.objects.get(id=id)
    delete_resume.delete()
    return redirect("/home")


class PDFUserDetailView(PDFTemplateResponseMixin, DetailView):
    model = Resume
    template_name = 'detail.html'

@login_required
def createResume(request):
    if request.method == "POST":
        myname = request.POST.get('name')
        myage = request.POST.get('age')
        myemail = request.POST.get('email')
        myphone = request.POST.get('phone')
        mygender = request.POST.get('gender')
        myaddress = request.POST.get('address')
        mydob = request.POST.get('dob')
        myskills = request.POST.get('skills')
        myprojects = request.POST.get('projects')
        myinternship = request.POST.get('internship')
        myschoolname = request.POST.get('schoolname')
        myschoolqualification = request.POST.get('schoolqualification')
        mycollegename = request.POST.get('collegename')
        mycollegequalification = request.POST.get('collegequalification')
        myuniversityname = request.POST.get('universityname')
        myuniversityqualification = request.POST.get(
            'universityqualification')
        myhobbies = request.POST.get('hobbies')
        mylanguages = request.POST.get('languages')
        mynationality = request.POST.get('nationality')
        mycertification = request.POST.get('certification')
        mystate = request.POST.get('state')
        mymarital = request.POST.get('maritalstatus')
        mysummary = request.POST.get('summary')

        r = Resume(name=myname, age=myage, email=myemail, gender=mygender, phone=myphone,
                   address=myaddress, dob=mydob, skills=myskills, projects=myprojects,
                   internship=myinternship, schoolname=myschoolname, schoolqualification=myschoolqualification,
                   collegename=mycollegename, collegequalification=mycollegequalification,
                   universityname=myuniversityname,
                   universityqualification=myuniversityqualification,
                   hobbies=myhobbies, languages=mylanguages, nationality=mynationality, certification=mycertification,
                   state=mystate, maritalstatus=mymarital, summary=mysummary)
        r.save()
        return redirect("/home")

    return render(request, "create.html")