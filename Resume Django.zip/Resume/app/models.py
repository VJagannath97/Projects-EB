from typing import AsyncContextManager
from django.db import models

# Create your models here.


class Resume(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    email = models.CharField(max_length=100)
    phone = models.IntegerField()
    gender = models.CharField(max_length=10)
    address = models.TextField()
    dob = models.DateField()
    skills = models.CharField(max_length=100)
    projects = models.TextField(max_length= 1000)
    internship = models.CharField(max_length=300)
    schoolname = models.CharField(max_length=100)
    schoolqualification = models.CharField(max_length=100)
    collegename = models.CharField(max_length=100)
    collegequalification = models.CharField(max_length=100)
    universityname = models.CharField(max_length=100)
    universityqualification = models.CharField(max_length=100)
    hobbies = models.CharField(max_length=300)
    languages = models.CharField(max_length=100)
    nationality = models.CharField(max_length=100)
    certification = models.TextField()
    state = models.CharField(max_length=100)
    maritalstatus = models.CharField(max_length=100)
    summary = models.TextField(max_length=1000)